from django.apps import AppConfig


class RecipeSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recipe_site'
